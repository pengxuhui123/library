create definer = root@localhost trigger before_delete_borrow
    before delete
    on student
    for each row
BEGIN
    DELETE FROM borrow WHERE sid = OLD.sid;
END;

